import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Destinasi Seimbang | DOSM Datathon 2026',
  description: 'Tourism pressure-to-prosperity intelligence for Malaysia.',
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>
}
